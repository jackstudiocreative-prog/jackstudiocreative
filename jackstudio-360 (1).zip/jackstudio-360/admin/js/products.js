// Products — list + 360° creator
import { api, upload, toast, esc, slugify, uniqueId, SERIES } from './api.js';
import { photosToFrames, videoToFrames, isVideo } from './media-tools.js';
import { SpinViewer } from '/assets/js/spin-viewer.js';

const MODEL_VIEWER = '/assets/vendor/model-viewer/model-viewer.min.js';

function framesOf(spin) {
  if (!spin) return [];
  return Array.from({ length: spin.count }, (_, i) =>
    `/${spin.folder}/${spin.pattern.replace('{n}', String(i + 1).padStart(spin.pad || 0, '0'))}`);
}

export function render(container, ctx) {
  return ctx.param ? renderEditor(container, ctx) : renderList(container, ctx);
}

/* ---------------- List ---------------- */

function renderList(container, { state, go }) {
  const items = state.products.map((p) => {
    const cover = framesOf(p.spin)[0] || (p.model?.poster ? `/${p.model.poster}` : '');
    const badges = [
      p.spin ? `<span class="badge">360° · ${p.spin.count} 张</span>` : '',
      p.model ? '<span class="badge">3D / AR</span>' : '',
      !p.spin && !p.model ? '<span class="badge badge--warn">未上传素材</span>' : '',
    ].join('');
    return `<li><button class="item" type="button" data-id="${esc(p.id)}">
      ${cover ? `<img src="${esc(cover)}" alt="" loading="lazy">` : '<div class="ph">无图片</div>'}
      <div class="body"><h3>${esc(p.name)}</h3><div class="meta">${p.series ? `<span>${esc(p.series)}</span>` : ''}${badges}</div></div>
    </button></li>`;
  }).join('');

  container.innerHTML = `
    <div class="page-head">
      <h1>产品 360°</h1>
      <div class="actions"><button class="btn" type="button" id="new-product">+ 新增产品</button></div>
    </div>
    ${state.products.length
      ? `<ul class="grid" style="list-style:none;margin:0;padding:0">${items}</ul>`
      : '<div class="empty">还没有产品。点「新增产品」，上传转盘照片或影片就能生成 360°。</div>'}`;

  container.querySelector('#new-product').addEventListener('click', () => go('#products/new'));
  container.querySelectorAll('[data-id]').forEach((b) => b.addEventListener('click', () => go(`#products/${encodeURIComponent(b.dataset.id)}`)));
  return {};
}

/* ---------------- Editor ---------------- */

function renderEditor(container, { state, param, go }) {
  const isNew = param === 'new';
  const original = isNew ? null : state.products.find((p) => p.id === param);
  if (!isNew && !original) throw new Error('找不到这个产品');

  const draft = structuredClone(original || { id: '', name: '', series: '', price: '', description: '', shopUrl: '', spin: null, model: null });
  const pending = { frames: null, frameUrls: [], glb: null, usdz: null, modelUrl: null };
  let viewer = null;
  let mode = 'spin';
  let busy = false;
  let videoFile = null;

  container.innerHTML = `
    <div class="page-head">
      <div>
        <button class="link-btn" type="button" id="back">← 全部产品</button>
        <h1 id="title">${isNew ? '新增产品' : esc(original.name)}</h1>
      </div>
      <div class="actions">
        ${isNew ? '' : `<a class="btn btn--ghost btn--sm" href="/product.html?id=${encodeURIComponent(original.id)}" target="_blank" rel="noopener">查看页面 ↗</a>`}
        ${isNew ? '' : '<button class="btn btn--danger btn--sm" type="button" id="delete">删除</button>'}
        <button class="btn" type="button" id="save">保存</button>
      </div>
    </div>

    <div class="editor">
      <div>
        <div class="viewer-tabs" id="tabs" role="tablist">
          <button type="button" role="tab" data-mode="spin" aria-selected="true">360° 照片</button>
          <button type="button" role="tab" data-mode="model" aria-selected="false">3D / AR</button>
        </div>
        <div class="preview-stage" id="stage"></div>

        <section class="panel" style="margin-top:16px">
          <h2>360° 照片</h2>
          <p class="sub">上传转盘照片（建议 24–72 张，按文件名排序），或一段转一圈的影片，系统会自动生成 360°。</p>
          <label class="drop" id="drop">
            <strong>拖放照片 / 影片到这里，或点击选择</strong>
            <span>JPG · PNG · WebP · MP4 · MOV</span>
            <input type="file" id="frames-input" accept="image/*,video/*" multiple hidden>
          </label>

          <div id="video-opts" hidden style="margin-top:14px">
            <div class="row">
              <div class="field">
                <label for="v-count">提取张数</label>
                <select class="select" id="v-count">
                  <option value="24">24（较轻）</option>
                  <option value="36" selected>36（推荐）</option>
                  <option value="48">48</option>
                  <option value="72">72（最顺滑）</option>
                </select>
              </div>
              <div class="field">
                <label>转一圈的时间段（秒）</label>
                <div class="inline">
                  <input class="input" id="v-start" type="number" min="0" step="0.1" value="0" style="width:90px" aria-label="开始秒数">
                  <span>到</span>
                  <input class="input" id="v-end" type="number" min="0" step="0.1" style="width:90px" aria-label="结束秒数">
                </div>
                <span class="hint" id="v-duration"></span>
              </div>
            </div>
            <button class="btn btn--sm" type="button" id="extract">从影片生成 360°</button>
          </div>

          <div class="progress" id="progress" hidden><i></i></div>
          <div class="status" id="status" aria-live="polite"></div>
          <div class="strip" id="strip"></div>
          <label class="check" style="margin-top:12px">
            <input type="checkbox" id="reverse" ${draft.spin?.reverse ? 'checked' : ''}> 旋转方向反过来
          </label>
        </section>
      </div>

      <div>
        <section class="panel">
          <h2>产品资料</h2>
          <div class="field">
            <label for="f-name">产品名称 *</label>
            <input class="input" id="f-name" value="${esc(draft.name)}" required>
          </div>
          <div class="field">
            <label for="f-id">网址代码</label>
            <input class="input" id="f-id" value="${esc(draft.id)}" ${isNew ? '' : 'readonly'} pattern="[a-z0-9][a-z0-9-]*">
            <span class="hint">${isNew ? '自动由名称生成，只能用英文小写、数字和 -' : '保存后不能更改'} · /product.html?id=<b id="id-preview">${esc(draft.id)}</b></span>
          </div>
          <div class="row">
            <div class="field">
              <label for="f-series">系列</label>
              <input class="input" id="f-series" list="series-list" value="${esc(draft.series)}">
              <datalist id="series-list">${SERIES.map((s) => `<option value="${esc(s)}">`).join('')}</datalist>
            </div>
            <div class="field">
              <label for="f-price">价格</label>
              <input class="input" id="f-price" value="${esc(draft.price)}" placeholder="RM 299">
            </div>
          </div>
          <div class="field">
            <label for="f-desc">介绍</label>
            <textarea class="textarea" id="f-desc">${esc(draft.description)}</textarea>
          </div>
          <div class="field">
            <label for="f-url">购买链接</label>
            <input class="input" id="f-url" type="url" value="${esc(draft.shopUrl)}" placeholder="https://">
          </div>
        </section>

        <section class="panel">
          <h2>3D 模型（可选）</h2>
          <p class="sub">Blender 导出 .glb（glTF Binary）。iPhone AR 可另外上传 .usdz。</p>
          <div class="field">
            <label for="f-glb">.glb 文件</label>
            <input class="input" id="f-glb" type="file" accept=".glb,model/gltf-binary">
            <span class="hint" id="glb-status">${draft.model ? '已有 3D 模型' : '未上传'}</span>
          </div>
          <div class="field">
            <label for="f-usdz">.usdz 文件（iPhone AR）</label>
            <input class="input" id="f-usdz" type="file" accept=".usdz">
          </div>
          ${draft.model ? '<button class="btn btn--danger btn--sm" type="button" id="remove-model">移除 3D 模型</button>' : ''}
        </section>
      </div>
    </div>`;

  const $ = (sel) => container.querySelector(sel);
  const stage = $('#stage');
  const status = (text) => { $('#status').textContent = text; };
  const progress = (v) => {
    const bar = $('#progress');
    bar.hidden = v == null;
    if (v != null) bar.firstElementChild.style.width = `${Math.round(v * 100)}%`;
  };

  /* ---- preview ---- */
  function currentFrames() { return pending.frameUrls.length ? pending.frameUrls : framesOf(draft.spin); }

  function showPreview() {
    viewer?.destroy?.();
    viewer = null;
    stage.innerHTML = '';
    if (mode === 'spin') {
      const frames = currentFrames();
      if (!frames.length) { stage.innerHTML = '<div class="ph">上传照片或影片后，这里会出现 360° 预览</div>'; return; }
      viewer = new SpinViewer(stage, frames, { reverse: $('#reverse').checked, label: draft.name || 'Preview' });
    } else {
      const src = pending.modelUrl || (draft.model?.glb ? `/${draft.model.glb}` : '');
      if (!src) { stage.innerHTML = '<div class="ph">上传 .glb 后，这里会出现 3D 预览</div>'; return; }
      loadModelViewer().then(() => {
        if (mode !== 'model') return;
        stage.innerHTML = `<model-viewer src="${esc(src)}" camera-controls shadow-intensity="0.6" alt="3D preview"></model-viewer>`;
      }).catch((e) => toast(e.message, true));
    }
  }

  function renderStrip() {
    const frames = currentFrames();
    const step = Math.max(1, Math.floor(frames.length / 24));
    $('#strip').innerHTML = frames.filter((_, i) => i % step === 0).map((src) => `<img src="${esc(src)}" alt="">`).join('');
  }

  $('#tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-mode]');
    if (!b) return;
    mode = b.dataset.mode;
    $('#tabs').querySelectorAll('[data-mode]').forEach((x) => x.setAttribute('aria-selected', x === b));
    showPreview();
  });

  /* ---- frames input ---- */
  function setPendingFrames(blobs) {
    pending.frameUrls.forEach(URL.revokeObjectURL);
    pending.frames = blobs;
    pending.frameUrls = blobs.map((b) => URL.createObjectURL(b));
    mode = 'spin';
    $('#tabs').querySelector('[data-mode="spin"]').click();
    renderStrip();
    status(`已生成 ${blobs.length} 张 · 记得按「保存」上传`);
  }

  async function handleFiles(files) {
    if (busy || !files.length) return;
    const video = [...files].find(isVideo);
    if (video) {
      videoFile = video;
      $('#video-opts').hidden = false;
      const probe = document.createElement('video');
      probe.preload = 'metadata';
      probe.src = URL.createObjectURL(video);
      probe.onloadedmetadata = () => {
        $('#v-end').value = probe.duration.toFixed(1);
        $('#v-duration').textContent = `影片长度 ${probe.duration.toFixed(1)} 秒`;
        URL.revokeObjectURL(probe.src);
      };
      status(`已选择影片：${video.name}。设定好后按「从影片生成 360°」`);
      return;
    }
    const images = [...files].filter((f) => f.type.startsWith('image/'));
    if (images.length < 8) { toast('至少需要 8 张照片才能做 360°', true); return; }
    busy = true;
    status(`正在处理 ${images.length} 张照片…`);
    try {
      setPendingFrames(await photosToFrames(images, { onProgress: progress }));
    } catch (err) { toast(err.message, true); status(''); }
    finally { busy = false; progress(null); }
  }

  const drop = $('#drop');
  $('#frames-input').addEventListener('change', (e) => { handleFiles(e.target.files); e.target.value = ''; });
  ['dragenter', 'dragover'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add('is-over'); }));
  ['dragleave', 'drop'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove('is-over'); }));
  drop.addEventListener('drop', (e) => handleFiles(e.dataTransfer.files));

  $('#extract').addEventListener('click', async () => {
    if (!videoFile || busy) return;
    busy = true;
    const count = Number($('#v-count').value);
    status(`正在从影片提取 ${count} 张…`);
    try {
      const frames = await videoToFrames(videoFile, {
        count, start: Number($('#v-start').value) || 0, end: Number($('#v-end').value) || null, onProgress: progress,
      });
      setPendingFrames(frames);
    } catch (err) { toast(err.message, true); status(''); }
    finally { busy = false; progress(null); }
  });

  $('#reverse').addEventListener('change', showPreview);

  /* ---- model ---- */
  $('#f-glb').addEventListener('change', (e) => {
    const f = e.target.files[0];
    if (!f) return;
    if (pending.modelUrl) URL.revokeObjectURL(pending.modelUrl);
    pending.glb = f;
    pending.modelUrl = URL.createObjectURL(f);
    $('#glb-status').textContent = `${f.name} · 记得按「保存」上传`;
    $('#tabs').querySelector('[data-mode="model"]').click();
  });
  $('#f-usdz').addEventListener('change', (e) => { pending.usdz = e.target.files[0] || null; });
  $('#remove-model')?.addEventListener('click', () => {
    if (!confirm('确定移除 3D 模型？')) return;
    draft.model = null;
    pending.glb = pending.usdz = null;
    pending.modelUrl = null;
    $('#remove-model').remove();
    $('#glb-status').textContent = '保存后会移除';
    showPreview();
  });

  /* ---- info fields ---- */
  const taken = new Set(state.products.map((p) => p.id));
  let idTouched = !isNew;
  $('#f-name').addEventListener('input', () => {
    if (isNew && !idTouched) {
      $('#f-id').value = uniqueId(slugify($('#f-name').value) || 'product', taken);
      $('#id-preview').textContent = $('#f-id').value;
    }
  });
  $('#f-id').addEventListener('input', () => {
    idTouched = true;
    $('#f-id').value = $('#f-id').value.toLowerCase().replace(/[^a-z0-9-]/g, '');
    $('#id-preview').textContent = $('#f-id').value;
  });

  function readForm() {
    draft.name = $('#f-name').value.trim();
    draft.id = $('#f-id').value.trim();
    draft.series = $('#f-series').value.trim();
    draft.price = $('#f-price').value.trim();
    draft.description = $('#f-desc').value.trim();
    draft.shopUrl = $('#f-url').value.trim();
    if (draft.spin) draft.spin.reverse = $('#reverse').checked || undefined;
  }

  /* ---- save / delete ---- */
  async function save() {
    if (busy) return;
    readForm();
    if (!draft.name) { toast('请填写产品名称', true); $('#f-name').focus(); return; }
    if (!/^[a-z0-9][a-z0-9-]{0,63}$/.test(draft.id)) { toast('网址代码只能用英文小写、数字和 -', true); $('#f-id').focus(); return; }
    if (isNew && taken.has(draft.id)) { toast('这个网址代码已被使用', true); return; }

    busy = true;
    $('#save').disabled = true;
    try {
      if (pending.frames) {
        status('正在上传 360° 照片…');
        const fd = new FormData();
        pending.frames.forEach((b, i) => fd.append('frames', b, `frame-${i + 1}.jpg`));
        const spin = await upload(`/api/upload/frames?product=${encodeURIComponent(draft.id)}`, fd, progress);
        draft.spin = { ...spin, ...($('#reverse').checked ? { reverse: true } : {}) };
      }
      if (pending.glb) {
        status('正在上传 3D 模型…');
        const fd = new FormData();
        fd.append('glb', pending.glb);
        if (pending.usdz) fd.append('usdz', pending.usdz);
        const model = await upload(`/api/upload/model?product=${encodeURIComponent(draft.id)}`, fd, progress);
        draft.model = { ...model, ...(draft.spin ? { poster: `${draft.spin.folder}/frame-${'1'.padStart(draft.spin.pad, '0')}.jpg` } : {}) };
      }
      status('正在保存…');
      const list = isNew ? [...state.products, draft] : state.products.map((p) => (p.id === original.id ? draft : p));
      const { products } = await api('PUT', '/api/products', { products: list });
      state.products = products;
      pending.frames = null;
      pending.glb = pending.usdz = null;
      saved = JSON.stringify(draft);
      toast('已保存');
      if (isNew) go(`#products/${encodeURIComponent(draft.id)}`);
      else { status(''); $('#title').textContent = draft.name; }
    } catch (err) {
      toast(err.message, true);
      status('');
    } finally {
      busy = false;
      progress(null);
      $('#save') && ($('#save').disabled = false);
    }
  }

  $('#save').addEventListener('click', save);
  $('#back').addEventListener('click', () => go('#products'));
  $('#delete')?.addEventListener('click', async () => {
    if (!confirm(`确定删除「${original.name}」？Showroom 里连到这个产品的热点也会失效。`)) return;
    try {
      const { products } = await api('PUT', '/api/products', { products: state.products.filter((p) => p.id !== original.id) });
      state.products = products;
      saved = null;
      pending.frames = pending.glb = null;
      toast('已删除');
      go('#products');
    } catch (err) { toast(err.message, true); }
  });

  let saved = JSON.stringify(draft);
  showPreview();
  renderStrip();

  return {
    isDirty() {
      if (saved === null) return false;
      readForm();
      return Boolean(pending.frames || pending.glb) || JSON.stringify(draft) !== saved;
    },
    destroy() {
      viewer?.destroy?.();
      pending.frameUrls.forEach(URL.revokeObjectURL);
      if (pending.modelUrl) URL.revokeObjectURL(pending.modelUrl);
    },
  };
}

function loadModelViewer() {
  if (customElements.get('model-viewer')) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.type = 'module';
    s.src = MODEL_VIEWER;
    s.onload = resolve;
    s.onerror = () => reject(new Error('Could not load 3D viewer'));
    document.head.append(s);
  });
}
