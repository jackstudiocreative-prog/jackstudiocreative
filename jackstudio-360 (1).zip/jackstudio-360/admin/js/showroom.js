// Showroom — scene list + visual hotspot editor
import { Viewer } from '@photo-sphere-viewer/core';
import { MarkersPlugin } from '@photo-sphere-viewer/markers-plugin';
import { api, upload, toast, esc, slugify, uniqueId } from './api.js';
import { preparePanorama } from './media-tools.js';

const ICONS = { scene: '→', product: '+', info: 'i' };
const TYPE_NAMES = { scene: '去另一个场景', product: '产品', info: '文字说明' };
const toDeg = (rad) => {
  let d = Math.round((rad * 180) / Math.PI);
  if (d > 180) d -= 360;
  if (d < -180) d += 360;
  return d;
};

export function render(container, { state }) {
  const draft = structuredClone(state.showroom || { title: 'Jack Studio Showroom', startScene: '', scenes: [] });
  const pending = new Map(); // sceneId -> { file, thumb, url, thumbUrl }
  let saved = JSON.stringify(draft);
  let sceneId = draft.startScene || draft.scenes[0]?.id || null;
  let selected = -1;      // selected hotspot index
  let placing = null;     // { type } to add, or { move: index }
  let viewer = null;
  let markers = null;
  let busy = false;

  const scene = () => draft.scenes.find((s) => s.id === sceneId);
  const panoSrc = (s) => pending.get(s.id)?.url || `/${s.panorama}`;
  const thumbSrc = (s) => pending.get(s.id)?.thumbUrl || (s.thumb ? `/${s.thumb}` : panoSrc(s));
  const productName = (id) => state.products.find((p) => p.id === id)?.name;
  const sceneName = (id) => draft.scenes.find((s) => s.id === id)?.name;

  container.innerHTML = `
    <div class="page-head">
      <h1>Showroom</h1>
      <div class="actions">
        <a class="btn btn--ghost btn--sm" href="/showroom.html" target="_blank" rel="noopener">查看页面 ↗</a>
        <button class="btn" type="button" id="save"><span id="dirty" hidden class="dirty-dot"></span>保存</button>
      </div>
    </div>
    <div class="sr">
      <aside>
        <ul class="scene-items" id="scenes"></ul>
        <label class="btn btn--ghost btn--sm" style="width:100%">
          + 新增场景
          <input type="file" id="add-scene" accept="image/jpeg,image/png,image/webp" hidden>
        </label>
        <p class="status" style="margin-top:10px">上传 2:1 的全景图（360° 相机拍的，或手机拍好拼接的）。</p>
        <div class="panel" style="margin-top:12px;padding:14px">
          <b style="font-size:13px">用普通手机拍</b>
          <p class="status" style="margin:6px 0 0">在手机打开
            <a href="${esc((state.siteUrl || '').replace(/\/$/, ''))}/capture/" target="_blank" rel="noopener" style="word-break:break-all">${esc((state.siteUrl || '').replace(/^https?:\/\//, '').replace(/\/$/, ''))}/capture/</a>，
            跟着圆点拍一圈，下载全景图后在这里「新增场景」上传。</p>
        </div>
      </aside>

      <section>
        <div class="sr-toolbar" id="toolbar">
          <button class="btn btn--sm" type="button" data-place="scene">→ 加场景连接</button>
          <button class="btn btn--sm" type="button" data-place="product">+ 加产品</button>
          <button class="btn btn--sm" type="button" data-place="info">i 加文字说明</button>
          <button class="btn btn--ghost btn--sm" type="button" id="set-view">把目前角度设为开场角度</button>
        </div>
        <div class="sr-stage" id="stage">
          <div class="sr-banner" id="banner" hidden><span id="banner-text"></span><button type="button" id="cancel-place">取消</button></div>
          <div id="pano" style="position:absolute;inset:0"></div>
        </div>
        <p class="status" id="status" aria-live="polite"></p>
      </section>

      <aside class="sr-side" id="side"></aside>
    </div>`;

  const $ = (sel) => container.querySelector(sel);
  const status = (t) => { $('#status').textContent = t; };
  const isDirty = () => pending.size > 0 || JSON.stringify(draft) !== saved;
  const markDirty = () => { $('#dirty').hidden = !isDirty(); };

  /* ---------- Scenes list ---------- */
  function renderScenes() {
    $('#scenes').innerHTML = draft.scenes.map((s) => `
      <li><button type="button" data-scene="${esc(s.id)}" aria-current="${s.id === sceneId}">
        <img src="${esc(thumbSrc(s))}" alt="">
        <span><b>${esc(s.name)}</b><small>${s.id === draft.startScene ? '开场场景 · ' : ''}${s.hotspots.length} 个热点</small></span>
      </button></li>`).join('') || '<li class="status">还没有场景</li>';
    const empty = !draft.scenes.length;
    $('#toolbar').querySelectorAll('button').forEach((b) => { b.disabled = empty; });
  }
  $('#scenes').addEventListener('click', (e) => {
    const b = e.target.closest('[data-scene]');
    if (b) selectScene(b.dataset.scene);
  });

  /* ---------- Viewer ---------- */
  function markerConfig(h, i) {
    const label = h.type === 'info' ? h.title : h.label || (h.type === 'scene' ? sceneName(h.target) : productName(h.product)) || '';
    return {
      id: `hs-${i}`,
      position: { yaw: `${h.yaw}deg`, pitch: `${h.pitch}deg` },
      html: `<div class="hs hs--${h.type}${i === selected ? ' is-selected' : ''}">
        <span class="hs-dot" aria-hidden="true">${ICONS[h.type]}</span>
        ${label ? `<span class="hs-label">${esc(label)}</span>` : ''}</div>`,
      anchor: 'center left',
      data: { index: i },
    };
  }
  function refreshMarkers() {
    const s = scene();
    markers?.setMarkers(s ? s.hotspots.map(markerConfig) : []);
  }

  function ensureViewer() {
    if (viewer || !scene()) return;
    const s = scene();
    $('#pano').innerHTML = '';
    viewer = new Viewer({
      container: $('#pano'),
      panorama: panoSrc(s),
      defaultYaw: `${s.view?.yaw || 0}deg`,
      defaultPitch: `${s.view?.pitch || 0}deg`,
      navbar: ['zoom', 'move', 'fullscreen'],
      plugins: [MarkersPlugin],
    });
    markers = viewer.getPlugin(MarkersPlugin);
    viewer.addEventListener('ready', refreshMarkers, { once: true });

    viewer.addEventListener('click', ({ data }) => {
      if (!placing || data.rightclick) return;
      const s = scene();
      const pos = { yaw: toDeg(data.yaw), pitch: toDeg(data.pitch) };
      if (placing.move != null) {
        Object.assign(s.hotspots[placing.move], pos);
        selected = placing.move;
      } else {
        const h = { type: placing.type, ...pos };
        if (h.type === 'scene') { const t = draft.scenes.find((x) => x.id !== s.id); h.target = t?.id || ''; h.label = ''; }
        if (h.type === 'product') { h.product = state.products[0]?.id || ''; h.label = ''; }
        if (h.type === 'info') { h.title = '标题'; h.text = ''; }
        s.hotspots.push(h);
        selected = s.hotspots.length - 1;
      }
      stopPlacing();
      refreshMarkers();
      renderSide();
      renderScenes();
      markDirty();
    });

    markers.addEventListener('select-marker', ({ marker }) => {
      if (placing) return;
      selected = marker.data.index;
      refreshMarkers();
      renderSide();
    });
  }

  async function selectScene(id) {
    sceneId = id;
    selected = -1;
    stopPlacing();
    renderScenes();
    renderSide();
    const s = scene();
    if (!s) return;
    if (!viewer) return ensureViewer();
    markers.clearMarkers();
    await viewer.setPanorama(panoSrc(s), {
      position: { yaw: `${s.view?.yaw || 0}deg`, pitch: `${s.view?.pitch || 0}deg` },
      transition: false,
    });
    refreshMarkers();
  }

  /* ---------- Placing mode ---------- */
  function startPlacing(p) {
    placing = p;
    $('#stage').classList.add('is-placing');
    $('#banner').hidden = false;
    $('#banner-text').textContent = p.move != null ? '在全景上点击新的位置' : `在全景上点击要放「${TYPE_NAMES[p.type]}」的位置`;
  }
  function stopPlacing() {
    placing = null;
    $('#stage').classList.remove('is-placing');
    $('#banner').hidden = true;
  }
  $('#toolbar').addEventListener('click', (e) => {
    const b = e.target.closest('[data-place]');
    if (!b) return;
    if (b.dataset.place === 'scene' && draft.scenes.length < 2) { toast('先新增第二个场景，才能连接', true); return; }
    if (b.dataset.place === 'product' && !state.products.length) { toast('先在「产品 360°」新增产品', true); return; }
    startPlacing({ type: b.dataset.place });
  });
  $('#cancel-place').addEventListener('click', stopPlacing);
  const onKey = (e) => { if (e.key === 'Escape' && placing) stopPlacing(); };
  document.addEventListener('keydown', onKey);

  $('#set-view').addEventListener('click', () => {
    if (!viewer || !scene()) return;
    const { yaw, pitch } = viewer.getPosition();
    scene().view = { yaw: toDeg(yaw), pitch: toDeg(pitch) };
    toast('已设定开场角度（记得保存）');
    markDirty();
  });

  /* ---------- Side panel: scene settings + hotspots ---------- */
  function renderSide() {
    const s = scene();
    const side = $('#side');
    if (!s) { side.innerHTML = ''; return; }
    const h = s.hotspots[selected];

    const hotspotList = s.hotspots.map((x, i) => {
      const name = x.type === 'info' ? x.title : x.label || (x.type === 'scene' ? sceneName(x.target) : productName(x.product)) || '（未设定）';
      return `<li><button type="button" data-hs="${i}" aria-current="${i === selected}">
        <span class="t t--${x.type}">${ICONS[x.type]}</span>${esc(name)}</button></li>`;
    }).join('');

    let form = '';
    if (h) {
      const sceneOptions = draft.scenes.filter((x) => x.id !== s.id)
        .map((x) => `<option value="${esc(x.id)}" ${x.id === h.target ? 'selected' : ''}>${esc(x.name)}</option>`).join('');
      const productOptions = state.products
        .map((p) => `<option value="${esc(p.id)}" ${p.id === h.product ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
      form = `
        <section class="panel" id="hs-form">
          <h2>${TYPE_NAMES[h.type]}</h2>
          <p class="sub">位置：yaw ${h.yaw}° · pitch ${h.pitch}°</p>
          ${h.type === 'scene' ? `
            <div class="field"><label for="h-target">去哪个场景</label>
              <select class="select" id="h-target" data-k="target">${sceneOptions}</select></div>
            <div class="field"><label for="h-label">按钮文字（可空，默认用场景名）</label>
              <input class="input" id="h-label" data-k="label" value="${esc(h.label)}"></div>` : ''}
          ${h.type === 'product' ? `
            <div class="field"><label for="h-product">产品</label>
              <select class="select" id="h-product" data-k="product">${productOptions}</select></div>
            <div class="field"><label for="h-label">标签文字（可空，默认用产品名）</label>
              <input class="input" id="h-label" data-k="label" value="${esc(h.label)}"></div>` : ''}
          ${h.type === 'info' ? `
            <div class="field"><label for="h-title">标题</label>
              <input class="input" id="h-title" data-k="title" value="${esc(h.title)}"></div>
            <div class="field"><label for="h-text">内容</label>
              <textarea class="textarea" id="h-text" data-k="text">${esc(h.text)}</textarea></div>` : ''}
          <div class="inline">
            <button class="btn btn--ghost btn--sm" type="button" id="h-move">移动位置</button>
            <button class="btn btn--danger btn--sm" type="button" id="h-delete">删除</button>
          </div>
        </section>`;
    }

    side.innerHTML = `
      ${form}
      <section class="panel">
        <h2>热点</h2>
        <p class="sub">${s.hotspots.length ? '点选热点来编辑' : '用上方按钮，在全景上点击放置热点'}</p>
        <ul class="hs-list">${hotspotList}</ul>
      </section>
      <section class="panel">
        <h2>场景设定</h2>
        <div class="field"><label for="s-name">场景名称</label>
          <input class="input" id="s-name" value="${esc(s.name)}"></div>
        <label class="check" style="margin-bottom:14px">
          <input type="checkbox" id="s-start" ${draft.startScene === s.id ? 'checked disabled' : ''}> 设为开场场景
        </label>
        <div class="inline">
          <label class="btn btn--ghost btn--sm">更换全景图
            <input type="file" id="s-replace" accept="image/jpeg,image/png,image/webp" hidden></label>
          <button class="btn btn--danger btn--sm" type="button" id="s-delete">删除场景</button>
        </div>
      </section>`;

    side.querySelector('.hs-list').addEventListener('click', (e) => {
      const b = e.target.closest('[data-hs]');
      if (!b) return;
      selected = Number(b.dataset.hs);
      refreshMarkers();
      renderSide();
      const target = s.hotspots[selected];
      viewer?.animate({ yaw: `${target.yaw}deg`, pitch: `${target.pitch}deg`, speed: '6rpm' });
    });

    side.querySelectorAll('[data-k]').forEach((el) => el.addEventListener('input', () => {
      s.hotspots[selected][el.dataset.k] = el.value;
      refreshMarkers();
      side.querySelector(`[data-hs="${selected}"]`)?.replaceWith(...renderTempItem(s, selected));
      markDirty();
    }));

    side.querySelector('#h-move')?.addEventListener('click', () => startPlacing({ move: selected }));
    side.querySelector('#h-delete')?.addEventListener('click', () => {
      s.hotspots.splice(selected, 1);
      selected = -1;
      refreshMarkers(); renderSide(); renderScenes(); markDirty();
    });

    side.querySelector('#s-name').addEventListener('input', (e) => {
      s.name = e.target.value;
      renderScenes(); markDirty();
    });
    side.querySelector('#s-start').addEventListener('change', () => {
      draft.startScene = s.id;
      renderScenes(); renderSide(); markDirty();
    });
    side.querySelector('#s-replace').addEventListener('change', async (e) => {
      const f = e.target.files[0];
      if (f) await addPanorama(f, s);
    });
    side.querySelector('#s-delete').addEventListener('click', () => {
      const links = draft.scenes.reduce((n, x) => n + x.hotspots.filter((hh) => hh.type === 'scene' && hh.target === s.id).length, 0);
      if (!confirm(`确定删除场景「${s.name}」？${links ? `其他场景里有 ${links} 个连到这里的热点也会一起删除。` : ''}`)) return;
      draft.scenes = draft.scenes.filter((x) => x.id !== s.id);
      draft.scenes.forEach((x) => { x.hotspots = x.hotspots.filter((hh) => !(hh.type === 'scene' && hh.target === s.id)); });
      pending.delete(s.id);
      if (draft.startScene === s.id) draft.startScene = draft.scenes[0]?.id || '';
      markDirty();
      if (draft.scenes.length) selectScene(draft.scenes[0].id);
      else { viewer?.destroy(); viewer = null; markers = null; sceneId = null; renderScenes(); renderSide(); }
    });
  }

  // Lightweight update of one hotspot list row while typing (keeps input focus)
  function renderTempItem(s, i) {
    const x = s.hotspots[i];
    const name = x.type === 'info' ? x.title : x.label || (x.type === 'scene' ? sceneName(x.target) : productName(x.product)) || '（未设定）';
    const b = document.createElement('button');
    b.type = 'button';
    b.dataset.hs = i;
    b.setAttribute('aria-current', 'true');
    b.innerHTML = `<span class="t t--${x.type}">${ICONS[x.type]}</span>${esc(name)}`;
    return [b];
  }

  /* ---------- Add / replace panorama ---------- */
  async function addPanorama(file, existing = null) {
    if (busy) return;
    busy = true;
    status('正在处理全景图…');
    try {
      const prep = await preparePanorama(file);
      if (prep.warning && !confirm(`${prep.warning}\n\n还是要使用这张图吗？`)) { status(''); return; }
      let s = existing;
      if (!s) {
        const base = file.name.replace(/\.[^.]+$/, '');
        const id = uniqueId(slugify(base) || 'scene', new Set(draft.scenes.map((x) => x.id)));
        s = { id, name: base.replace(/[-_]+/g, ' ').slice(0, 60) || '新场景', panorama: '', view: { yaw: 0, pitch: 0 }, hotspots: [] };
        draft.scenes.push(s);
        if (!draft.startScene) draft.startScene = s.id;
      }
      const old = pending.get(s.id);
      if (old) { URL.revokeObjectURL(old.url); URL.revokeObjectURL(old.thumbUrl); }
      pending.set(s.id, { file: prep.file, thumb: prep.thumb, url: URL.createObjectURL(prep.file), thumbUrl: URL.createObjectURL(prep.thumb) });
      markDirty();
      status(`${prep.width}×${prep.height} · 记得按「保存」上传`);
      if (s.id === sceneId && viewer) {
        await viewer.setPanorama(panoSrc(s), { transition: false });
        refreshMarkers();
        renderScenes();
      } else {
        await selectScene(s.id);
      }
    } catch (err) {
      toast(err.message, true);
      status('');
    } finally {
      busy = false;
    }
  }
  $('#add-scene').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    e.target.value = '';
    if (f) await addPanorama(f);
  });

  /* ---------- Save ---------- */
  $('#save').addEventListener('click', async () => {
    if (busy) return;
    busy = true;
    $('#save').disabled = true;
    try {
      for (const [id, p] of pending) {
        const s = draft.scenes.find((x) => x.id === id);
        if (!s) continue;
        status(`正在上传「${s.name}」全景图…`);
        const fd = new FormData();
        fd.append('panorama', p.file, `${id}.jpg`);
        fd.append('thumb', p.thumb, `${id}-thumb.jpg`);
        const res = await upload(`/api/upload/panorama?scene=${encodeURIComponent(id)}`, fd);
        s.panorama = res.panorama;
        if (res.thumb) s.thumb = res.thumb;
        // keep showing the local copy; it is identical to the uploaded file
      }
      status('正在保存…');
      const { showroom } = await api('PUT', '/api/showroom', draft);
      state.showroom = showroom;
      pending.forEach((p) => { URL.revokeObjectURL(p.thumbUrl); });
      pending.clear();
      saved = JSON.stringify(draft);
      markDirty();
      renderScenes();
      status('');
      toast('已保存');
    } catch (err) {
      toast(err.message, true);
      status('');
    } finally {
      busy = false;
      $('#save').disabled = false;
    }
  });

  /* ---------- Init ---------- */
  renderScenes();
  renderSide();
  if (scene()) ensureViewer();
  else $('#pano').innerHTML = '<div class="empty" style="margin:24px;background:var(--ivory)">点左边「新增场景」上传第一张全景图</div>';

  return {
    isDirty,
    destroy() {
      document.removeEventListener('keydown', onKey);
      viewer?.destroy();
      pending.forEach((p) => { URL.revokeObjectURL(p.url); URL.revokeObjectURL(p.thumbUrl); });
    },
  };
}
