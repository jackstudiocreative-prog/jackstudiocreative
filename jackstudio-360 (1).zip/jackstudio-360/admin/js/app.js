// Admin app shell: login, navigation, shared state
import { api, toast } from './api.js';
import * as productsView from './products.js';
import * as showroomView from './showroom.js';

const VIEWS = { products: productsView, showroom: showroomView };
const $ = (id) => document.getElementById(id);

const state = { showroom: null, products: [], siteUrl: '' };
let current = null; // { name, instance }

async function loadData() {
  const data = await api('GET', '/api/data');
  state.showroom = data.showroom;
  state.products = data.products;
  state.siteUrl = data.siteUrl || '';
}

function parseHash() {
  const [name = 'products', ...rest] = location.hash.replace(/^#\/?/, '').split('/');
  return { name: VIEWS[name] ? name : 'products', param: rest.join('/') ? decodeURIComponent(rest.join('/')) : '' };
}

function isDirty() {
  return current?.instance?.isDirty?.() || false;
}

async function route() {
  const { name, param } = parseHash();
  current?.instance?.destroy?.();
  document.querySelectorAll('[data-view]').forEach((b) => b.setAttribute('aria-current', b.dataset.view === name ? 'page' : 'false'));
  const container = $('view');
  container.innerHTML = '';
  window.scrollTo(0, 0);
  try {
    const instance = await VIEWS[name].render(container, { state, param, go, reload: loadData });
    current = { name, instance };
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="empty">${err.message}</div>`;
  }
}

function go(hash) {
  if (location.hash === hash) route();
  else location.hash = hash;
}

// Guard unsaved changes
let lastHash = location.hash;
window.addEventListener('hashchange', () => {
  if (isDirty() && !confirm('有未保存的更改，确定要离开吗？')) {
    history.replaceState(null, '', lastHash || '#products');
    return;
  }
  lastHash = location.hash;
  route();
});
window.addEventListener('beforeunload', (e) => {
  if (isDirty()) { e.preventDefault(); e.returnValue = ''; }
});

document.querySelectorAll('[data-view]').forEach((b) => b.addEventListener('click', () => go(`#${b.dataset.view}`)));

$('logout').addEventListener('click', async () => {
  if (isDirty() && !confirm('有未保存的更改，确定要登出吗？')) return;
  await api('POST', '/api/logout').catch(() => {});
  location.reload();
});

$('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('login-error').textContent = '';
  try {
    await api('POST', '/api/login', { password: $('password').value });
    await start();
  } catch (err) {
    $('login-error').textContent = err.message === 'Wrong password' ? '密码错误' : err.message;
  }
});

async function start() {
  await loadData();
  $('login-view').hidden = true;
  $('app-view').hidden = false;
  lastHash = location.hash;
  route();
}

(async () => {
  try {
    const { authed } = await api('GET', '/api/me');
    if (authed) return start();
  } catch (err) {
    toast(err.message, true);
  }
  $('login-view').hidden = false;
  $('password').focus();
})();
