// Jack Studio 360 — self-hosted server (Node.js 20+, no npm packages needed)
// Serves the public 360 site, the /admin creator, and a small JSON API.
'use strict';

const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const ADMIN = path.join(ROOT, 'admin');
const DATA = path.join(PUBLIC, 'data');
const MEDIA = path.join(PUBLIC, 'media');
const BACKUPS = path.join(ROOT, 'backups');
const CONFIG_FILE = path.join(ROOT, 'config.json');

const MAX_JSON = 2 * 1024 * 1024;        // 2 MB
const MAX_UPLOAD = 120 * 1024 * 1024;    // 120 MB per upload request
const ID_RE = /^[a-z0-9][a-z0-9-]{0,63}$/;
const SESSION_HOURS = 12;

/* ---------- Config (created on first run) ---------- */

function loadConfig() {
  let cfg = {};
  if (fs.existsSync(CONFIG_FILE)) cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
  let changed = false;
  if (!cfg.adminPassword) {
    cfg.adminPassword = crypto.randomBytes(9).toString('base64url');
    changed = true;
    if (!process.env.ADMIN_PASSWORD) console.log(`\n  New admin password created: ${cfg.adminPassword}\n  (change it in config.json)\n`);
  }
  if (!cfg.sessionSecret) { cfg.sessionSecret = crypto.randomBytes(32).toString('hex'); changed = true; }
  if (!cfg.port) { cfg.port = 3600; changed = true; }
  if (!cfg.siteUrl) { cfg.siteUrl = 'https://360.jackstudio.com.my'; changed = true; }
  if (changed) fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2));
  if (process.env.ADMIN_PASSWORD) cfg.adminPassword = process.env.ADMIN_PASSWORD;
  if (process.env.PORT) cfg.port = Number(process.env.PORT);
  return cfg;
}
const config = loadConfig();

/* ---------- Helpers ---------- */

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
  '.webp': 'image/webp', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.glb': 'model/gltf-binary',
  '.usdz': 'model/vnd.usdz+zip', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml; charset=utf-8',
  '.ico': 'image/x-icon',
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'X-Content-Type-Options': 'nosniff', ...headers });
  res.end(body);
}
function json(res, status, obj) {
  send(res, status, JSON.stringify(obj), { 'Content-Type': TYPES['.json'], 'Cache-Control': 'no-store' });
}

async function readBody(req, limit) {
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > limit) throw httpError(413, 'Upload too large');
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw httpError(413, 'Upload too large');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}
async function readJSON(req) {
  try { return JSON.parse((await readBody(req, MAX_JSON)).toString('utf8')); }
  catch (e) { throw e.status ? e : httpError(400, 'Invalid JSON'); }
}
async function readForm(req) {
  const body = await readBody(req, MAX_UPLOAD);
  return new Request('http://local/', { method: 'POST', headers: { 'content-type': req.headers['content-type'] || '' }, body }).formData();
}

function httpError(status, message) { const e = new Error(message); e.status = status; return e; }

async function writeFileAtomic(file, data) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  await fsp.writeFile(tmp, data);
  await fsp.rename(tmp, file);
}

async function readDataFile(name, fallback) {
  try { return JSON.parse(await fsp.readFile(path.join(DATA, name), 'utf8')); }
  catch { return fallback; }
}

async function saveDataFile(name, obj) {
  const file = path.join(DATA, name);
  // keep the last 20 versions of each data file in /backups
  if (fs.existsSync(file)) {
    await fsp.mkdir(BACKUPS, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    await fsp.copyFile(file, path.join(BACKUPS, `${name.replace('.json', '')}-${stamp}.json`));
    const old = (await fsp.readdir(BACKUPS)).filter((f) => f.startsWith(name.replace('.json', '') + '-')).sort();
    for (const f of old.slice(0, -20)) await fsp.unlink(path.join(BACKUPS, f)).catch(() => {});
  }
  await writeFileAtomic(file, JSON.stringify(obj, null, 2) + '\n');
}

function fileKind(buf) {
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'jpg';
  if (buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'webp';
  if (buf.slice(0, 4).toString() === 'glTF') return 'glb';
  if (buf[0] === 0x50 && buf[1] === 0x4b) return 'usdz'; // zip container
  return null;
}

async function fileBuffer(file) {
  if (!file || typeof file.arrayBuffer !== 'function') return null;
  return Buffer.from(await file.arrayBuffer());
}

const str = (v, max = 500) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const num = (v, min, max, dflt = 0) => (Number.isFinite(Number(v)) ? Math.min(max, Math.max(min, Number(v))) : dflt);
const mediaPath = (v) => (typeof v === 'string' && /^media\/[a-z0-9/_.-]+$/i.test(v) && !v.includes('..') ? v : null);

/* ---------- Auth ---------- */

function sign(value) {
  return crypto.createHmac('sha256', config.sessionSecret).update(value).digest('base64url');
}
function makeSession() {
  const exp = String(Date.now() + SESSION_HOURS * 3600 * 1000);
  return `${exp}.${sign(exp)}`;
}
function isAuthed(req) {
  const cookie = (req.headers.cookie || '').split(';').map((c) => c.trim()).find((c) => c.startsWith('js360='));
  if (!cookie) return false;
  const [exp, sig] = cookie.slice(6).split('.');
  if (!exp || !sig) return false;
  const expected = sign(exp);
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
  return Number(exp) > Date.now();
}
function sessionCookie(req, value, maxAge) {
  const secure = req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
  return `js360=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure}`;
}

const attempts = new Map(); // ip -> { count, until }
function rateLimited(ip) {
  const now = Date.now();
  const a = attempts.get(ip) || { count: 0, until: now + 60_000 };
  if (now > a.until) { a.count = 0; a.until = now + 60_000; }
  a.count += 1;
  attempts.set(ip, a);
  return a.count > 8;
}
function passwordOk(input) {
  const a = Buffer.from(sign(String(input || '')));
  const b = Buffer.from(sign(config.adminPassword));
  return crypto.timingSafeEqual(a, b);
}

/* ---------- Validation of saved data ---------- */

function cleanShowroom(input) {
  const scenes = Array.isArray(input?.scenes) ? input.scenes : [];
  const ids = new Set();
  const out = scenes.map((s) => {
    if (!ID_RE.test(s.id) || ids.has(s.id)) throw httpError(400, `Invalid or duplicate scene id: ${s.id}`);
    ids.add(s.id);
    const panorama = mediaPath(s.panorama);
    if (!panorama) throw httpError(400, `Scene "${s.id}" has no panorama`);
    return {
      id: s.id,
      name: str(s.name, 80) || s.id,
      panorama,
      thumb: mediaPath(s.thumb) || undefined,
      view: { yaw: num(s.view?.yaw, -180, 180), pitch: num(s.view?.pitch, -90, 90) },
      hotspots: (Array.isArray(s.hotspots) ? s.hotspots : []).slice(0, 100).map((h) => {
        const base = { type: h.type, yaw: num(h.yaw, -180, 180), pitch: num(h.pitch, -90, 90) };
        if (h.type === 'scene') return { ...base, target: str(h.target, 64), label: str(h.label, 60) };
        if (h.type === 'product') return { ...base, product: str(h.product, 64), label: str(h.label, 60) };
        if (h.type === 'info') return { ...base, title: str(h.title, 80), text: str(h.text, 600) };
        throw httpError(400, `Unknown hotspot type: ${h.type}`);
      }),
    };
  });
  const start = ids.has(input.startScene) ? input.startScene : out[0]?.id || '';
  return { title: str(input?.title, 80) || 'Jack Studio Showroom', startScene: start, scenes: out };
}

function cleanProducts(input) {
  const list = Array.isArray(input?.products) ? input.products : [];
  const ids = new Set();
  return {
    products: list.map((p) => {
      if (!ID_RE.test(p.id) || ids.has(p.id)) throw httpError(400, `Invalid or duplicate product id: ${p.id}`);
      ids.add(p.id);
      const spin = p.spin && mediaPath(p.spin.folder) ? {
        folder: mediaPath(p.spin.folder),
        pattern: /^[a-z0-9_-]*\{n\}\.(jpg|jpeg|png|webp)$/i.test(p.spin.pattern) ? p.spin.pattern : 'frame-{n}.jpg',
        count: num(p.spin.count, 1, 720, 36),
        pad: num(p.spin.pad, 0, 4, 2),
        ...(p.spin.reverse ? { reverse: true } : {}),
      } : null;
      const model = p.model && mediaPath(p.model.glb) ? {
        glb: mediaPath(p.model.glb),
        ...(mediaPath(p.model.usdz) ? { usdz: mediaPath(p.model.usdz) } : {}),
        ...(mediaPath(p.model.poster) ? { poster: mediaPath(p.model.poster) } : {}),
      } : null;
      const shopUrl = /^https?:\/\//i.test(p.shopUrl || '') ? str(p.shopUrl, 400) : '';
      return {
        id: p.id, name: str(p.name, 100) || p.id, series: str(p.series, 60), price: str(p.price, 40),
        description: str(p.description, 1000), shopUrl, spin, model,
      };
    }),
  };
}

/* ---------- Media clean-up: remove files no saved scene/product uses ---------- */

async function cleanupMedia() {
  const showroom = await readDataFile('showroom.json', { scenes: [] });
  const { products = [] } = await readDataFile('products.json', { products: [] });
  const used = new Set();
  showroom.scenes.forEach((s) => { used.add(s.panorama); if (s.thumb) used.add(s.thumb); });
  products.forEach((p) => {
    if (p.spin) used.add(p.spin.folder + '/');
    if (p.model) Object.values(p.model).forEach((v) => used.add(v));
  });
  const isUsed = (rel) => used.has(rel) || [...used].some((u) => u.endsWith('/') && (rel + '/').startsWith(u));
  const graceMs = 15 * 60 * 1000; // never delete fresh uploads that may not be saved yet

  async function walk(dir) {
    let entries = [];
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const full = path.join(dir, e.name);
      const rel = path.relative(PUBLIC, full).split(path.sep).join('/');
      const stat = await fsp.stat(full);
      if (Date.now() - stat.mtimeMs < graceMs) continue;
      if (e.isDirectory()) {
        if (/\/spin-\d+$/.test(rel) && !isUsed(rel)) await fsp.rm(full, { recursive: true, force: true });
        else await walk(full);
      } else if (/-\d{10,}(-thumb)?\.(jpg|png|webp|glb|usdz)$/.test(e.name) && !isUsed(rel)) {
        await fsp.unlink(full).catch(() => {});
      }
    }
  }
  await walk(MEDIA);
}

/* ---------- Sitemap & robots ---------- */

async function writeSeoFiles() {
  const { products = [] } = await readDataFile('products.json', { products: [] });
  const site = config.siteUrl.replace(/\/$/, '');
  const today = new Date().toISOString().slice(0, 10);
  const urls = [`${site}/`, `${site}/showroom.html`, ...products.map((p) => `${site}/product.html?id=${encodeURIComponent(p.id)}`)];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${
    urls.map((u) => `  <url><loc>${u.replace(/&/g, '&amp;')}</loc><lastmod>${today}</lastmod></url>`).join('\n')}\n</urlset>\n`;
  await writeFileAtomic(path.join(PUBLIC, 'sitemap.xml'), xml);
  await writeFileAtomic(path.join(PUBLIC, 'robots.txt'),
    `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\nDisallow: /*edit=1\nDisallow: /*embed=1\n\nSitemap: ${site}/sitemap.xml\n`);
}

/* ---------- API ---------- */

async function api(req, res, url) {
  const route = `${req.method} ${url.pathname}`;
  const ip = req.socket.remoteAddress;

  if (route === 'POST /api/login') {
    if (rateLimited(ip)) return json(res, 429, { error: 'Too many attempts. Wait a minute.' });
    const { password } = await readJSON(req);
    if (!passwordOk(password)) return json(res, 401, { error: 'Wrong password' });
    res.setHeader('Set-Cookie', sessionCookie(req, makeSession(), SESSION_HOURS * 3600));
    return json(res, 200, { ok: true });
  }
  if (route === 'POST /api/logout') {
    res.setHeader('Set-Cookie', sessionCookie(req, '', 0));
    return json(res, 200, { ok: true });
  }
  if (route === 'GET /api/me') return json(res, 200, { authed: isAuthed(req) });

  if (!isAuthed(req)) return json(res, 401, { error: 'Please log in' });
  // Only accept writes from our own pages
  if (req.method !== 'GET' && req.headers['x-js360'] !== '1') return json(res, 403, { error: 'Forbidden' });

  if (route === 'GET /api/data') {
    return json(res, 200, {
      showroom: await readDataFile('showroom.json', { title: 'Jack Studio Showroom', startScene: '', scenes: [] }),
      products: (await readDataFile('products.json', { products: [] })).products,
      siteUrl: config.siteUrl,
    });
  }

  if (route === 'PUT /api/showroom') {
    const clean = cleanShowroom(await readJSON(req));
    await saveDataFile('showroom.json', clean);
    cleanupMedia().catch(console.error);
    return json(res, 200, { ok: true, showroom: clean });
  }

  if (route === 'PUT /api/products') {
    const clean = cleanProducts(await readJSON(req));
    await saveDataFile('products.json', clean);
    await writeSeoFiles();
    cleanupMedia().catch(console.error);
    return json(res, 200, { ok: true, products: clean.products });
  }

  // Upload a scene panorama (+ thumbnail made in the browser)
  if (route === 'POST /api/upload/panorama') {
    const id = url.searchParams.get('scene');
    if (!ID_RE.test(id || '')) throw httpError(400, 'Invalid scene id');
    const form = await readForm(req);
    const pano = await fileBuffer(form.get('panorama'));
    const thumb = await fileBuffer(form.get('thumb'));
    const kind = pano && fileKind(pano);
    if (!['jpg', 'png', 'webp'].includes(kind)) throw httpError(400, 'Panorama must be JPG, PNG or WebP');
    const stamp = Date.now();
    const dir = path.join(MEDIA, 'showroom');
    await fsp.mkdir(dir, { recursive: true });
    const result = { panorama: `media/showroom/${id}-${stamp}.${kind}` };
    await fsp.writeFile(path.join(PUBLIC, result.panorama), pano);
    if (thumb && fileKind(thumb) === 'jpg') {
      result.thumb = `media/showroom/${id}-${stamp}-thumb.jpg`;
      await fsp.writeFile(path.join(PUBLIC, result.thumb), thumb);
    }
    return json(res, 200, result);
  }

  // Upload the ordered frames of a product spin
  if (route === 'POST /api/upload/frames') {
    const id = url.searchParams.get('product');
    if (!ID_RE.test(id || '')) throw httpError(400, 'Invalid product id');
    const form = await readForm(req);
    const frames = form.getAll('frames');
    if (frames.length < 8 || frames.length > 720) throw httpError(400, 'Upload between 8 and 720 frames');
    const folder = `media/products/${id}/spin-${Date.now()}`;
    await fsp.mkdir(path.join(PUBLIC, folder), { recursive: true });
    const pad = String(frames.length).length < 2 ? 2 : String(frames.length).length;
    for (let i = 0; i < frames.length; i++) {
      const buf = await fileBuffer(frames[i]);
      if (fileKind(buf) !== 'jpg') throw httpError(400, `Frame ${i + 1} is not a JPG`);
      await fsp.writeFile(path.join(PUBLIC, folder, `frame-${String(i + 1).padStart(pad, '0')}.jpg`), buf);
    }
    return json(res, 200, { folder, pattern: 'frame-{n}.jpg', count: frames.length, pad });
  }

  // Upload a 3D model (GLB, optional USDZ for iPhone AR)
  if (route === 'POST /api/upload/model') {
    const id = url.searchParams.get('product');
    if (!ID_RE.test(id || '')) throw httpError(400, 'Invalid product id');
    const form = await readForm(req);
    const glb = await fileBuffer(form.get('glb'));
    if (!glb || fileKind(glb) !== 'glb') throw httpError(400, 'Model must be a .glb file');
    const stamp = Date.now();
    const dir = path.join(MEDIA, 'products', id);
    await fsp.mkdir(dir, { recursive: true });
    const result = { glb: `media/products/${id}/model-${stamp}.glb` };
    await fsp.writeFile(path.join(PUBLIC, result.glb), glb);
    const usdz = await fileBuffer(form.get('usdz'));
    if (usdz && fileKind(usdz) === 'usdz') {
      result.usdz = `media/products/${id}/model-${stamp}.usdz`;
      await fsp.writeFile(path.join(PUBLIC, result.usdz), usdz);
    }
    return json(res, 200, result);
  }

  return json(res, 404, { error: 'Not found' });
}

/* ---------- Static files ---------- */

async function serveStatic(req, res, url) {
  let base = PUBLIC;
  let rel;
  try { rel = decodeURIComponent(url.pathname); } catch { return send(res, 400, 'Bad request'); }
  if (rel === '/admin') { res.writeHead(301, { Location: '/admin/' }); return res.end(); }
  if (rel.startsWith('/admin/')) { base = ADMIN; rel = rel.slice(6); }
  if (rel.endsWith('/')) rel += 'index.html';

  const file = path.join(base, path.normalize(rel));
  if (!file.startsWith(base + path.sep)) return send(res, 403, 'Forbidden');

  let stat;
  try { stat = await fsp.stat(file); } catch { return send(res, 404, 'Not found', { 'Content-Type': 'text/plain' }); }
  if (!stat.isFile()) return send(res, 404, 'Not found');

  const ext = path.extname(file).toLowerCase();
  const headers = { 'Content-Type': TYPES[ext] || 'application/octet-stream', 'Content-Length': stat.size };
  if (base === ADMIN) { headers['Cache-Control'] = 'no-store'; headers['X-Frame-Options'] = 'DENY'; }
  else if (/^\/media\/.*-\d{10,}/.test(rel) || /\/spin-\d+\//.test(rel)) headers['Cache-Control'] = 'public, max-age=31536000, immutable';
  else if (ext === '.html' || ext === '.json' || ext === '.xml' || ext === '.txt') headers['Cache-Control'] = 'no-cache';
  else headers['Cache-Control'] = 'public, max-age=86400';

  res.writeHead(200, { 'X-Content-Type-Options': 'nosniff', ...headers });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

/* ---------- Server ---------- */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed');
    return await serveStatic(req, res, url);
  } catch (err) {
    if (!err.status) console.error(err);
    if (!res.headersSent) json(res, err.status || 500, { error: err.status ? err.message : 'Server error' });
  }
});

writeSeoFiles().catch(console.error);
server.listen(config.port, () => {
  console.log(`Jack Studio 360 running:
  Website  http://localhost:${config.port}/
  Admin    http://localhost:${config.port}/admin/`);
});
